import { Description, FieldError, Input, Label, TextField } from "@heroui/react"
import type { ReactNode } from "react"
import { FieldMessages } from "./FieldMessages"

export function Field({
  label,
  value,
  onChange,
  onBlur,
  placeholder,
  isRequired,
  isDisabled,
  isInvalid,
  errorMessage,
  description,
  autoFocus,
  reserveMessage,
  className = "",
}: {
  label: string
  value: string
  onChange: (value: string) => void
  onBlur?: () => void
  placeholder?: string
  isRequired?: boolean
  isDisabled?: boolean
  isInvalid?: boolean
  errorMessage?: string
  description?: ReactNode
  autoFocus?: boolean
  reserveMessage?: boolean
  className?: string
}) {
  return (
    <TextField
      value={value}
      onChange={onChange}
      onBlur={onBlur}
      isRequired={isRequired}
      isDisabled={isDisabled}
      isInvalid={isInvalid}
      className={`flex max-w-md flex-col gap-1 ${className}`}
    >
      {/* No manual "*": HeroUI marks a required label through CSS. */}
      <Label className="text-body">{label}</Label>
      <Input placeholder={placeholder} autoFocus={autoFocus} />
      <FieldMessages reserve={reserveMessage}>
        {description ? <Description className="text-muted">{description}</Description> : null}
        {errorMessage ? <FieldError className="text-danger">{errorMessage}</FieldError> : null}
      </FieldMessages>
    </TextField>
  )
}
